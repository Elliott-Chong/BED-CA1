cd backend
npm install
npm run server
