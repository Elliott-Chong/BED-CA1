import express from "express";
import connection from "../model/database.js";
import util from "util";

const app = express();
let query = util.promisify(connection.query).bind(connection);

app.use(express.json());

app.get("/", async (req, res) => {
  res.send("BED Assignment REST API Running");
});

// Endpoint 1
app.get("/actors/:actor_id", async (req, res) => {
  const actor_id = req.params.actor_id;
  try {
    const response = await query(
      "SELECT actor_id, first_name, last_name FROM actor WHERE actor_id = ?",
      [actor_id]
    );
    if (response.length === 0) {
      return res
        .status(204)
        .send("No Content. Record of given actor_id cannot be found.");
    }
    return res.status(200).json(response[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @GET /actors/:actor_id");
  }
});

// Endpoint 2
app.get("/actors", async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 20;
    const offset = parseInt(req.query.offset) || 0;
    const response = await query(
      "SELECT actor_id, first_name, last_name FROM actor LIMIT ? OFFSET ?",
      [limit, offset]
    );
    return res.status(200).json(response);
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @GET /actors");
  }
});

// Endpoint 3
app.post("/actors", async (req, res) => {
  try {
    const { first_name, last_name } = req.body;
    if (!first_name || !last_name) {
      return res.status(400).json({
        error_msg: "missing data",
      });
    }

    const response = await query(
      "INSERT INTO actor (first_name, last_name) VALUES (?, ?)",
      [first_name, last_name]
    );
    return res.status(200).json({ actor_id: response.insertId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @POST /actors");
  }
});

// Endpoint 4
app.put("/actors/:actor_id", async (req, res) => {
  let { first_name, last_name } = req.body;
  const { actor_id } = req.params;
  if (!first_name && !last_name) {
    return res.status(400).json({
      error_msg: "missing data",
    });
    // return res
    //   .status(400)
    //   .send("Missing first_name or last_name in request body");
  }
  try {
    let response = await query("SELECT * FROM actor WHERE actor_id =? ", [
      actor_id,
    ]);
    if (!first_name) {
      first_name = response[0].first_name;
    }
    if (!last_name) {
      last_name = response[0].last_name;
    }
    if (response.length === 0) {
      return res
        .status(204)
        .send("No Content. Record of given actor_id cannot be found.");
    }
    await query("UPDATE actor set first_name=?, last_name=? where actor_id=?", [
      first_name,
      last_name,
      actor_id,
    ]);
    return res.status(200).json({
      success_msg: "record updated",
    });
    // return res.status(200).send("Record updated!");
  } catch (error) {
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @PUT /actors/:actor_id");
  }
});

// Endpoint 5
app.delete("/actors/:actor_id", async (req, res) => {
  const { actor_id } = req.params;
  try {
    const response = await query("SELECT * FROM actor where actor_id=?", [
      actor_id,
    ]);
    if (response.length === 0) {
      return res.status(204);
    }
    await query("DELETE FROM actor where actor_id=?", [actor_id]);
    return res.status(200).json({
      success_msg: "actor deleted",
    });
  } catch (error) {
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @DELETE /actors/:actor_id");
  }
});

// Endpoint 6
app.get("/film_categories/:category_id/films", async (req, res) => {
  const { category_id } = req.params;
  try {
    const response = await query(
      "SELECT film.film_id, film.title, category.name as category, film.rating, film.release_year, film.length as duration from film join film_category on film_category.film_id=film.film_id join category on category.category_id=film_category.category_id WHERE category.category_id =?;",
      [category_id]
    );
    return res.status(200).json(response);
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // .send("Server error in @GET /film_categories/:category_id/films");
  }
});

// endpoint 7
app.get("/customer/:customer_id/payment", async (req, res) => {
  const { customer_id } = req.params;
  const { start_date, end_date } = req.query;
  try {
    const payment_response = await query(
      'select film.title, payment.amount, DATE_FORMAT(payment.payment_date, "%Y-%m-%d %T") as payment_date\
      from payment\
      join rental on payment.rental_id=rental.rental_id\
      join inventory on rental.inventory_id = inventory.inventory_id\
      join film on film.film_id = inventory.film_id \
      where payment.customer_id=?\
      and payment.payment_date > ?\
      and payment.payment_date < ?',
      [customer_id, start_date, end_date]
    );

    const aggregate_response = await query(
      "select sum(payment.amount) as total\
      from payment\
      join rental on payment.rental_id=rental.rental_id\
      join inventory on rental.inventory_id = inventory.inventory_id\
      join film on film.film_id = inventory.film_id \
      where payment.customer_id=?\
      and payment.payment_date > ?\
      and payment.payment_date < ?",
      [customer_id, start_date, end_date]
    );
    let total = aggregate_response[0].total;
    if (payment_response.length === 0) {
      total = 0;
    }

    return res.status(200).json({
      rental: payment_response,
      total,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // .send("Server error in @GET /film_categories/:category_id/films");
  }
});

// endpoint 8
app.post("/customers", async (req, res) => {
  try {
    const { first_name, last_name, store_id, email, address } = req.body;
    if (!address) {
      return res.status(400).json({
        error_msg: "missing data",
      });
    }
    const {
      address_line1,
      address_line2,
      district,
      city_id,
      postal_code,
      phone,
    } = address;
    // check if any data is missing from the body
    if (
      !first_name ||
      !last_name ||
      !store_id ||
      !email ||
      !address_line1 ||
      !district ||
      !city_id ||
      !postal_code ||
      !phone
    ) {
      return res.status(400).json({
        error_msg: "missing data",
      });
    }
    let response = await query(
      "SELECT email from customer WHERE email LIKE ?",
      [email]
    );
    if (response.length !== 0) {
      return res.status(409).json({
        error_msg: "email already exist",
      });
    }
    let address_response = await query(
      "INSERT INTO address (address, address2, district, city_id, postal_code, phone) VALUES (?, ?, ?, ?, ?, ?)",
      [address_line1, address_line2, district, city_id, postal_code, phone]
    );

    response = await query(
      "INSERT INTO customer (first_name, last_name, store_id, email, address_id) VALUES (?, ?, ?, ?, ?)",
      [first_name, last_name, store_id, email, address_response.insertId]
    );
    let insertId = response.insertId;
    return res.status(200).json({ customer_id: insertId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @POST /actors");
  }
});

// Additional endpoint 1
// endpoint 8
app.post("/store", async (req, res) => {
  try {
    const { manager_stuff_id, addresss_id } = req.body;
    if (!manager_stuff_id || !addresss_id) {
      return res.status(400).json({
        error_msg: "missing data",
      });
    }
    let response = await query("INSERT INTO store () VALUES ()");
    let insertId = response.insertId;
    return res.status(200).json({ customer_id: insertId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      error_msg: "Internal server error",
    });
    // return res.status(500).send("Server error in @POST /actors");
  }
});

app.listen(8000, () => {
  console.log("BED CA1 Running on http://localhost:" + 8000);
});
